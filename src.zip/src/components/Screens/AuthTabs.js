import React, { useState } from 'react';
import LoginForm from '../auth/LoginForm';
import SignupForm from '../auth/SignupForm';
import OTPLoginForm from '../auth/OTPLoginForm';
import '../auth/auth.css';

const AuthTabs = ({ onLogin }) => {
  const [activeTab, setActiveTab] = useState('login');

  return (
    <div className="auth-container">
      <div className="auth-tabs">
        <button className={activeTab === 'login' ? 'active' : ''} onClick={() => setActiveTab('login')}>Login</button>
        <button className={activeTab === 'signup' ? 'active' : ''} onClick={() => setActiveTab('signup')}>Signup</button>
        <button className={activeTab === 'otp' ? 'active' : ''} onClick={() => setActiveTab('otp')}>OTP Login</button>
      </div>

      {activeTab === 'login' && <LoginForm onLogin={onLogin} />}
      {activeTab === 'signup' && <SignupForm onLogin={onLogin} />}
      {activeTab === 'otp' && <OTPLoginForm onLogin={onLogin} />}
    </div>
  );
};

export default AuthTabs;
