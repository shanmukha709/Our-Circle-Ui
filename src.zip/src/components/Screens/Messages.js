import React, { useEffect, useState, useRef } from 'react';
import axios from 'axios';
import '../screens-styles/messages.css';

const Messages = () => {
  const [message, setMessage] = useState('');
  const [chat, setChat] = useState([]);
  const scrollRef = useRef(null);

  const sender = localStorage.getItem('username');
  const receiver = localStorage.getItem('chatUser');

  useEffect(() => {
    if (sender && receiver) {
      axios
        .get(`http://localhost:8083/chat/history/${sender}/${receiver}`)
        .then((res) => setChat(res.data))
        .catch((err) => console.error('Chat fetch error:', err));
    }
  }, [sender, receiver]);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chat]);

  const sendMessage = () => {
    if (!message.trim()) return;
    if (!sender || !receiver) return;

    const msgObj = {
      senderUsername: sender,
      receiverUsername: receiver,
      content: message,
    };

    axios
      .post('http://localhost:8083/chat/send', msgObj)
      .then((res) => {
        setChat((prev) => [...prev, res.data]);
        setMessage('');
      })
      .catch((err) => {
        console.error('Send error:', err);
        alert('Failed to send message. Please try again.');
      });
  };

  return (
    <div className="chat-wrapper">
      <h2 className="chat-header">Chat with {receiver}</h2>

      <div className="chat-body">
        {chat.length === 0 ? (
          <p className="no-messages">No messages yet.</p>
        ) : (
          chat.map((msg, idx) => {
            const isSender = msg.senderUsername === sender;
            return (
              <div
                key={idx}
                className={`chat-bubble ${isSender ? 'sent' : 'received'}`}
              >
                {!isSender && (
                  <div className="chat-username">{msg.senderUsername}</div>
                )}
                <div className="chat-text">{msg.content}</div>
                <div className="chat-time">
                  {new Date(msg.timestamp || Date.now()).toLocaleTimeString([], {
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </div>
              </div>
            );
          })
        )}
        <div ref={scrollRef}></div>
      </div>

      <div className="chat-input">
        <input
          type="text"
          placeholder="Type your message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button onClick={sendMessage} disabled={!message.trim()}>
          Send
        </button>
      </div>
    </div>
  );
};

export default Messages;
