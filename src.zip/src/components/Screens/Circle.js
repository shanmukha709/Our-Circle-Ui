import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../screens-styles/circle.css';
import { FaComments } from 'react-icons/fa';

const Circle = () => {
  const [citizens, setCitizens] = useState([]);
  const [expandedCardId, setExpandedCardId] = useState(null);
  const [areaDetailsMap, setAreaDetailsMap] = useState({});
  const [designationDetailsMap, setDesignationDetailsMap] = useState({});

  useEffect(() => {
    axios.get('http://localhost:8080/citizen')
      .then(response => setCitizens(response.data))
      .catch(error => console.error("Error fetching citizens:", error));
  }, []);

  const handleCardClick = async (citizen) => {
    if (!citizen || !citizen.id) return;

    if (expandedCardId === citizen.id) {
      setExpandedCardId(null);
    } else {
      setExpandedCardId(citizen.id);

      if (citizen.areaId && !areaDetailsMap[citizen.areaId]) {
        try {
          const res = await axios.get(`http://localhost:8080/areas/${citizen.areaId}`);
          setAreaDetailsMap((prev) => ({
            ...prev,
            [citizen.areaId]: res.data,
          }));
        } catch (error) {
          console.error("Error fetching area details:", error);
        }
      }

      if (citizen.designationId && !designationDetailsMap[citizen.designationId]) {
        try {
          const res = await axios.get(`http://localhost:8081/designation/${citizen.designationId}`);
          setDesignationDetailsMap((prev) => ({
            ...prev,
            [citizen.designationId]: res.data,
          }));
        } catch (error) {
          console.error("Error fetching designation details:", error);
        }
      }
    }
  };

  const handleChatClick = (e, citizen) => {
    e.stopPropagation(); // Prevent card toggle
    if (!citizen?.username) return;

    localStorage.setItem("chatUser", citizen.username);
    localStorage.setItem("selectedTab", "messages");
    window.location.reload(); // Triggers Messages.js to load
  };

  return (
    <div className="profile-container">
      <h2 className="profile-title">All Citizens</h2>

      <div className="profile-grid">
        {citizens.map((citizen) => {
          const isExpanded = expandedCardId === citizen.id;
          const areaDetails = citizen.area || areaDetailsMap[citizen.areaId] || {};
          const designationDetails = citizen.designation || designationDetailsMap[citizen.designationId] || {};

          return (
            <div
              key={citizen.id}
              className={`profile-card ${isExpanded ? 'expanded' : ''}`}
              onClick={() => handleCardClick(citizen)}
            >
              <div className="profile-avatar">
                {citizen.name && citizen.name[0] ? citizen.name[0].toUpperCase() : '?'}
              </div>
              <h3 className="profile-name">@{citizen.username}</h3>
              <p className='profile-real-name'>{citizen.name}</p>

              {isExpanded && (
                <div className="extra-info">
                  <p className="profile-info">Age: {citizen.age}</p>
                  <p className="profile-info">Gender: {citizen.gender}</p>

                  <p className="profile-info font-bold">Area Name: {areaDetails.name}</p>
                  <p className="profile-info">About Description: {areaDetails.description || areaDetails.about}</p>

                  <p className="profile-info font-bold">Profession: {designationDetails.profession}</p>
                  <p className="profile-info">About: {designationDetails.about}</p>

                  {/* Chat icon section */}
                  <div className="chat-icon-wrapper">
                    <FaComments
                      className="chat-icon"
                      title="Chat"
                      onClick={(e) => handleChatClick(e, citizen)}
                    />
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Circle;
