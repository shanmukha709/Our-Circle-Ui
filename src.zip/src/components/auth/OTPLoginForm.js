import React, { useState } from 'react';
import axios from '../api/axios';

const OTPLoginForm = ({ onLogin, switchToLogin }) => {
  const [type, setType] = useState('mobile');
  const [value, setValue] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);

  const requestOtp = async () => {
    try {
      const payload = type === 'email' ? { email: value } : { mobile: value };
      await axios.post(type === 'email' ? 'http://localhost:8082/auth/email/send-otp' : 'http://localhost:8082/auth/mobile/send-otp', payload);
      setOtpSent(true);
      alert('OTP sent successfully');
    } catch {
      alert('Failed to send OTP');
    }
  };

  const verifyOtp = async (e) => {
    e.preventDefault();
    try {
      const payload = type === 'email' ? { email: value, otp } : { mobile: value, otp };
      const response = await axios.post(type === 'email' ? 'http://localhost:8082/auth/login/email/otp' : 'http://localhost:8082/auth/login/mobile/otp', payload);
      localStorage.setItem('jwtToken', response.data);
      onLogin();
    } catch {
      alert('Invalid OTP or login failed');
    }
  };

  return (
    <form className="auth-form" onSubmit={verifyOtp}>
      <h2>OTP Login</h2>

      <select value={type} onChange={(e) => {
        setOtpSent(false);
        setType(e.target.value);
        setValue('');
        setOtp('');
      }}>
        <option value="mobile">Mobile</option>
        <option value="email">Email</option>
      </select>

      <input type="text" placeholder={type === 'email' ? 'Enter Email' : 'Enter Mobile'} value={value} onChange={(e) => setValue(e.target.value)} required />

      {otpSent && (
        <input type="text" placeholder="Enter OTP" value={otp} onChange={(e) => setOtp(e.target.value)} required />
      )}

      {!otpSent ? (
        <button type="button" onClick={requestOtp}>Send OTP</button>
      ) : (
        <button type="submit">Verify OTP</button>
      )}

      <p className="auth-links-single" onClick={switchToLogin}>Back to Login</p>
    </form>
  );
};

export default OTPLoginForm;
