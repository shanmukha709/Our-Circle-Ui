import React, { useState } from 'react';
import LoginForm from '../auth/LoginForm';
import SignupForm from '../auth/SignupForm';
import OTPLoginForm from '../auth/OTPLoginForm';
import '../auth/auth.css';

const AuthContainer = ({ onLogin }) => {
  const [activeForm, setActiveForm] = useState('login');

  return (
    <div className="auth-container">
      {activeForm === 'login' && <LoginForm onLogin={onLogin} switchToOtp={() => setActiveForm('otp')} switchToSignup={() => setActiveForm('signup')} />}
      {activeForm === 'otp' && <OTPLoginForm onLogin={onLogin} switchToLogin={() => setActiveForm('login')} />}
      {activeForm === 'signup' && <SignupForm onLogin={onLogin} switchToLogin={() => setActiveForm('login')} />}
    </div>
  );
};

export default AuthContainer;
