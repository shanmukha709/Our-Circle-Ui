import React, { useState } from 'react';
import axios from '../api/axios';

const SignupForm = ({ onLogin, switchToLogin }) => {
  const [data, setData] = useState({ username: '', email: '', mobile: '', password: '' });

  const handleSignup = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:8082/auth/signup', data);
      alert('Signup successful!');
      switchToLogin();
    } catch {
      alert('Signup failed');
    }
  };

  return (
    <form className="auth-form" onSubmit={handleSignup}>
      <h2>Sign Up</h2>
      <input type="text" placeholder="Username" value={data.username} onChange={(e) => setData({ ...data, username: e.target.value })} required />
      <input type="email" placeholder="Email" value={data.email} onChange={(e) => setData({ ...data, email: e.target.value })} required />
      <input type="text" placeholder="Mobile" value={data.mobile} onChange={(e) => setData({ ...data, mobile: e.target.value })} required />
      <input type="password" placeholder="Password" value={data.password} onChange={(e) => setData({ ...data, password: e.target.value })} required />
      <button type="submit">Sign Up</button>
      <p className="auth-links-single" onClick={switchToLogin}>Back to Login</p>
    </form>
  );
};

export default SignupForm;
